﻿# Remove o Sobrevivência Urbana deste computador (os atalhos e a cópia do app).
$destino = Join-Path $env:LOCALAPPDATA 'SobrevivenciaUrbana'
$atalhos = @(
  (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Sobrevivência Urbana.lnk'),
  (Join-Path ([Environment]::GetFolderPath('Programs')) 'Sobrevivência Urbana.lnk')
)
foreach ($a in $atalhos) { if (Test-Path $a) { Remove-Item $a -Force } }
if (Test-Path $destino) { Remove-Item $destino -Recurse -Force }
Write-Host ''
Write-Host 'O Sobrevivência Urbana foi removido.' -ForegroundColor Green
Write-Host 'Os dados que você digitou continuam guardados no navegador. Para apagá-los,'
Write-Host 'antes de desinstalar use a aba Dados > Apagar tudo, dentro do app.'
