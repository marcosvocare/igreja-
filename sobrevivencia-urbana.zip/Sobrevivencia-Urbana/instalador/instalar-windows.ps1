﻿# Instala o Sobrevivência Urbana neste computador (Windows 10 e 11).
$ErrorActionPreference = 'Stop'
$origem = Join-Path $PSScriptRoot '..\app'
$destino = Join-Path $env:LOCALAPPDATA 'SobrevivenciaUrbana'
Write-Host ''
Write-Host 'Instalando o Sobrevivência Urbana...' -ForegroundColor Green

if (Test-Path $destino) { Remove-Item $destino -Recurse -Force }
New-Item -ItemType Directory -Path $destino -Force | Out-Null
Copy-Item -Path (Join-Path $origem '*') -Destination $destino -Recurse -Force

$pagina = Join-Path $destino 'index.html'
$endereco = ([System.Uri]$pagina).AbsoluteUri

# Abre numa janela própria (modo aplicativo) do Edge ou do Chrome; senão, no navegador padrão.
$navegadores = @(
  (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
  (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
  (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
)
$navegador = $navegadores | Where-Object { Test-Path $_ } | Select-Object -First 1

$shell = New-Object -ComObject WScript.Shell
function Criar-Atalho([string]$caminho) {
  $atalho = $shell.CreateShortcut($caminho)
  if ($navegador) {
    $atalho.TargetPath = $navegador
    $atalho.Arguments = '--app="' + $endereco + '"'
  } else {
    $atalho.TargetPath = $pagina
  }
  $atalho.WorkingDirectory = $destino
  $atalho.IconLocation = (Join-Path $destino 'icone.ico')
  $atalho.Description = 'Plano de sobrevivência urbana - funciona sem internet'
  $atalho.Save()
}

$naAreaDeTrabalho = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Sobrevivência Urbana.lnk'
$noMenuIniciar = Join-Path ([Environment]::GetFolderPath('Programs')) 'Sobrevivência Urbana.lnk'
Criar-Atalho $naAreaDeTrabalho
Criar-Atalho $noMenuIniciar

Write-Host ''
Write-Host 'Pronto! O ícone "Sobrevivência Urbana" está na área de trabalho e no menu Iniciar.' -ForegroundColor Green
Write-Host 'O app funciona sem internet. Os dados ficam só neste computador.'
Start-Process $naAreaDeTrabalho
