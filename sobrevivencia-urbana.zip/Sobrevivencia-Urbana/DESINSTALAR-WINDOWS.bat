@echo off
rem Remove o Sobrevivencia Urbana deste computador.
title Desinstalar Sobrevivencia Urbana
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\desinstalar-windows.ps1"
echo.
pause
