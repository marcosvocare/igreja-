#!/bin/bash
# Instala o Sobrevivência Urbana: copia o app e cria o atalho no menu e na área de trabalho.
set -e
cd "$(dirname "$0")"
DESTINO="$HOME/.local/share/sobrevivencia-urbana"
echo "Instalando o Sobrevivência Urbana..."
rm -rf "$DESTINO"
mkdir -p "$DESTINO"
cp -R app/. "$DESTINO/"

ENDERECO="file://${DESTINO// /%20}/index.html"
NAV=""
for N in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge brave-browser; do
  if command -v "$N" >/dev/null 2>&1; then NAV="$N"; break; fi
done
if [ -n "$NAV" ]; then EXEC="$NAV \"--app=$ENDERECO\""; else EXEC="xdg-open \"$DESTINO/index.html\""; fi

ATALHO="[Desktop Entry]
Type=Application
Name=Sobrevivência Urbana
Comment=Plano de sobrevivência urbana - funciona sem internet
Exec=$EXEC
Icon=$DESTINO/icones/icone-192.png
Terminal=false
Categories=Utility;"

mkdir -p "$HOME/.local/share/applications"
printf '%s\n' "$ATALHO" > "$HOME/.local/share/applications/sobrevivencia-urbana.desktop"
AREA="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
if [ -d "$AREA" ]; then
  printf '%s\n' "$ATALHO" > "$AREA/sobrevivencia-urbana.desktop"
  chmod +x "$AREA/sobrevivencia-urbana.desktop"
  gio set "$AREA/sobrevivencia-urbana.desktop" metadata::trusted true >/dev/null 2>&1 || true
fi
echo ""
echo "Pronto! O atalho \"Sobrevivência Urbana\" está no menu de aplicativos e na área de trabalho."
echo "O app funciona sem internet. Os dados ficam só neste computador."
