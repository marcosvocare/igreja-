#!/bin/bash
# Instala o Sobrevivência Urbana neste Mac: copia o app e cria o ícone em Aplicativos e na Mesa.
set -e
cd "$(dirname "$0")"
DESTINO="$HOME/Library/Application Support/SobrevivenciaUrbana"
APP="$HOME/Applications/Sobrevivência Urbana.app"
echo "Instalando o Sobrevivência Urbana..."
rm -rf "$DESTINO" "$APP"
mkdir -p "$DESTINO" "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp -R app/. "$DESTINO/"

cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>Sobrevivência Urbana</string>
  <key>CFBundleDisplayName</key><string>Sobrevivência Urbana</string>
  <key>CFBundleIdentifier</key><string>io.github.marcosvocare.sobrevivencia-urbana</string>
  <key>CFBundleExecutable</key><string>abrir</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleIconFile</key><string>icone</string>
</dict>
</plist>
PLIST

cat > "$APP/Contents/MacOS/abrir" <<'ABRIR'
#!/bin/bash
# Abre numa janela própria (Chrome, Edge ou Brave); senão, no Safari ou navegador padrão.
PAGINA="$HOME/Library/Application Support/SobrevivenciaUrbana/index.html"
ENDERECO="file://${PAGINA// /%20}"
for NAV in "Google Chrome" "Microsoft Edge" "Brave Browser" "Chromium"; do
  if [ -d "/Applications/$NAV.app" ] || [ -d "$HOME/Applications/$NAV.app" ]; then
    open -na "$NAV" --args --app="$ENDERECO"
    exit 0
  fi
done
open "$PAGINA"
ABRIR
chmod +x "$APP/Contents/MacOS/abrir"

# Ícone do app (se as ferramentas do Mac estiverem disponíveis).
if command -v sips >/dev/null 2>&1 && command -v iconutil >/dev/null 2>&1; then
  TEMP="$(mktemp -d)/icone.iconset"
  mkdir -p "$TEMP"
  for T in 16 32 128 256; do
    sips -z $T $T app/icones/icone-512.png --out "$TEMP/icon_${T}x${T}.png" >/dev/null 2>&1 || true
    sips -z $((T * 2)) $((T * 2)) app/icones/icone-512.png --out "$TEMP/icon_${T}x${T}@2x.png" >/dev/null 2>&1 || true
  done
  cp app/icones/icone-512.png "$TEMP/icon_512x512.png"
  iconutil -c icns "$TEMP" -o "$APP/Contents/Resources/icone.icns" >/dev/null 2>&1 || true
fi

ln -sfn "$APP" "$HOME/Desktop/Sobrevivência Urbana"
echo ""
echo "Pronto! O ícone \"Sobrevivência Urbana\" está em Aplicativos e na Mesa."
echo "O app funciona sem internet. Os dados ficam só neste Mac."
open "$APP"
