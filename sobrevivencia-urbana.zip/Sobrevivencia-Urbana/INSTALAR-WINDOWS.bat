@echo off
rem Instala o Sobrevivencia Urbana neste computador e cria o icone na area de trabalho.
title Instalar Sobrevivencia Urbana
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\instalar-windows.ps1"
echo.
pause
